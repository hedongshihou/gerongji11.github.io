<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
  exit( 'Direct script access denied.' );
}

do_action('MagicBookAdmin_header');

$plugins           = TGM_Plugin_Activation::$instance->plugins;
$installed_plugins = get_plugins();
?>
<div class="wrap about-wrap magicbook-wrap">
  <?php 
  add_thickbox(); 
  $key_url_md5 = 'Wswb86sr07^d1a7y#';
  ?>
   <div class="box">
        <?php echo wp_kses_post(__( 'Visual Composer and MagicBook Addon are required to use MagicBook. ', 'magicbook' ) ); ?>
  </div>

  <?php if ( !MagicBookAdmin::check_license() ) : ?>
    <div class="box" style="border-left: 4px solid #dc3232;">
      <h3 style="color: #dc3232; margin-top: 0;"><?php esc_attr_e( 'Premium Plugins Can Only Be Installed and Updated With A Valid Purchase Code Registration', 'magicbook' ); ?></h3>
      <p><?php printf( esc_attr__( 'Please visit the %s page and enter a valid purchase code to install or update the premium plugins: Slider Revolution, Visual Composer and MagicBook Addon.', 'magicbook' ), '<a href="' . esc_url_raw( admin_url( 'themes.php?page=magicbook-registration' ) ) . '">' . esc_attr__( 'Registration', 'magicbook' ) . '</a>' ); ?></p>
    </div>
  <?php endif; ?>

  <div class="magicbook-admin-grid">
    <div class="feature-section theme-browser rendered">
      <?php $magicbook_registered_plugins = magicbook_get_required_and_recommened_plugins(); ?>
      <?php foreach ( $plugins as $plugin ) : ?>
        <?php
        if ( ! array_key_exists( $plugin['slug'], $magicbook_registered_plugins ) ) {
          continue;
        }

        $class = '';
        $plugin_status = '';
        $file_path = $plugin['file_path'];
        $plugin_action = MagicBookAdmin::plugin_link( $plugin );

        // We have a repo plugin.
        if ( ! $plugin['version'] ) {
          $plugin['version'] = TGM_Plugin_Activation::$instance->does_plugin_have_update( $plugin['slug'] );
        }

        if ( is_plugin_active( $file_path ) ) {
          $plugin_status = 'active';
          $class = 'active';
        }
        ?>
        <div class="theme <?php echo esc_attr( $class ); ?>">
          <div class="theme-wrapper">
            <div class="theme-screenshot">
              <img src="<?php echo esc_url_raw( $plugin['image_url'] ); ?>" alt="" />
              <div class="plugin-info">
                <?php if ( isset( $installed_plugins[ $plugin['file_path'] ] ) ) : ?>
                  <?php echo wp_kses_post( sprintf( __( 'Version: %1$s | <a href="%2$s" target="_blank">%3$s</a>', 'magicbook' ), esc_attr( $installed_plugins[ $plugin['file_path'] ]['Version'] ), esc_url_raw( $installed_plugins[ $plugin['file_path'] ]['AuthorURI'] ), esc_attr( $installed_plugins[ $plugin['file_path'] ]['Author'] ) ) ); ?>
                <?php elseif ( 'bundled' == $plugin['source_type'] ) : ?>
                  <?php printf( esc_attr__( 'Available Version: %s', 'magicbook' ), esc_attr( $plugin['version'] ) ); ?>
                <?php endif; ?>
              </div>
            </div>
            <?php if ( isset( $plugin_action['update'] ) && $plugin_action['update'] ) : ?>
              <div class="update-message notice inline notice-warning notice-alt magicbook-plugin-update-notice">
                <p><?php printf( esc_attr__( 'New Version Available: %s', 'magicbook' ), esc_attr( $plugin['version'] ) ); ?></p>
              </div>
            <?php endif; ?>
            <h3 class="theme-name">
              <?php if ( 'active' == $plugin_status ) : ?>
                <span><?php printf( esc_attr__( 'Active: %s', 'magicbook' ), esc_attr( $plugin['name'] ) ); ?></span>
              <?php else : ?>
                <?php echo esc_attr( $plugin['name'] ); ?>
              <?php endif; ?>
            </h3>
            <div class="theme-actions">
              <?php foreach ( $plugin_action as $action ) : ?>
                <?php
                echo $action;
                ?>
              <?php endforeach; ?>
            </div>
            <?php if ( isset( $plugin['required'] ) && $plugin['required'] ) : ?>
              <div class="plugin-required">
                <?php esc_html_e( 'Required', 'magicbook' ); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="magicbook-thanks">
    <p class="description"><?php esc_html_e( 'Thank you for choosing MagicBook. We are honored and are fully dedicated to making your experience perfect.', 'magicbook' ); ?></p>
  </div>

 </div>

 <div style="clear: both;"></div>
</div>