<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
  exit( 'Direct script access denied.' );
}

do_action('MagicBookAdmin_header');
?>
<div class="section">
      <h3><?php esc_html_e('Please enter your purchase code to activate auto theme updates and install the bundled premium plugins.','magicbook');?></h3>
      <form method="post" action="options.php"> 
         <?php 
          settings_fields( 'magicbook_option_group' );
          do_settings_sections( 'magicbook_option_group' ); 
          echo MagicBookAdmin::text('purchase_key','');
          submit_button('Submit','primary','submit_purchase_key','',''); ;

          if( MagicBookAdmin::check_license()) {
            echo '<div class="activated">'.esc_html__('Your License Key is Activated!','magicbook').'</div>';
          }else{
            echo '<div class="warning">'.esc_html__('Invalid License Key or ThemeVan.com server is not responding, if you are sure the purchase code is correct, please contact us through johnwu@themevan.com','magicbook').'</div>';
          }
         ?>
      </form>
      <div class="box">
        <h3><?php esc_html_e('Where to get your purchase code?','magicbook');?></h3>
        <p><?php esc_html_e('Go to your Themeforest Download Page, click the green download button, then just select "License Certificate & Purchase Code" to download the license text file, you can find the purchase code in this file.','magicbook');?></p>
        <p><img src="<?php echo MAGICBOOK_INC_URI;?>admin/img/download.jpg" style="width:50%" /><img src="<?php echo MAGICBOOK_INC_URI;?>admin/img/purchase_code.jpg" style="width:50%" /></p>
      </div>
  </div>

</div>
