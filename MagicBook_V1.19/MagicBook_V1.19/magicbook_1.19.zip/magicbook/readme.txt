MagicBook Theme is developed by ThemeVan and designed by Kevin Studio
If you have any questions, you can ask on the support forum: http://www.themevan.com/support

===============================================================
The credits of icons
===============================================================

- User designed by Maurizio Fusillo from the Noun Project
  http://thenounproject.com/term/user/40851/

- Folder designed by hunotika from the Noun Project
  http://thenounproject.com/term/folder/41075/

- Comment designed by P.J. Onori from the Noun Project
  http://thenounproject.com/term/comment/2793/

- Camera designed by Bart Laugs from the Noun Project
  http://thenounproject.com/term/camera/1537/

- Painting designed by Ilsur Aptukov from the Noun Project
  http://thenounproject.com/term/painting/24023/

- Image designed by Hello Many from the Noun Project
  http://thenounproject.com/term/image/65572/

- Warning designed by Milky - Digital innovation from the Noun Project
  http://thenounproject.com/term/warning/33183/


===============================================================
The credits of picture
===============================================================

Pictures in Fashion Demo:
https://www.flickr.com/photos/xvire/
https://www.flickr.com/photos/thomasleuthard/
https://www.flickr.com/photos/payalnic/
https://www.flickr.com/photos/gagilas/
https://www.flickr.com/photos/xvire/
https://www.flickr.com/photos/astragony/
https://www.flickr.com/photos/mr-h/
https://www.flickr.com/photos/johnonolan/
https://www.flickr.com/photos/s-t-r-a-n-g-e/
https://www.flickr.com/photos/carianoff/
https://www.flickr.com/photos/thomasleuthard

===============================================================
The credits of plugins
===============================================================

- Gallery Metabox
  https://wordpress.org/plugins/gallery-metabox/

- Visual Composer (Purchased Extend license)
  http://codecanyon.net/item/visual-composer-page-builder-for-wordpress/242431

- Redux Framework
  http://reduxframework.com