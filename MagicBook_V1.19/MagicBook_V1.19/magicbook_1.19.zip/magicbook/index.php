<?php
/* --------------------------
 * Default Index Page
 ---------------------------*/
get_header();
get_template_part('default','menu');
van_home_page();
get_footer();
